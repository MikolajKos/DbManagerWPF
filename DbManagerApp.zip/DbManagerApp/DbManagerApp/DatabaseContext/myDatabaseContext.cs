﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DbManagerApp.DatabaseContext
{
    public class myDatabaseContext : DbContext
    {
        private string databasePath = "";

        public myDatabaseContext(string path)
        {
            this.databasePath = path;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(databasePath);
        }
    }
}
