﻿using DbManagerApp.Core;
using DbManagerApp.MVVM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbManagerApp.MVVM.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        MainModel model = new MainModel();

        public string selectedPathProp 
        {
            get
            {
                return model.selectedFilePath;
            }
            set
            {
                model.selectedFilePath = value;
                onPropertyChanged(nameof(selectedPathProp));
            }
        }
    }
}
